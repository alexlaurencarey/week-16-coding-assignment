import React from "react";

const About = () => {
  return (
    <div>
      <h1>Find your Favorite Recipes Here</h1>
    </div>
  );
};

export default About;
