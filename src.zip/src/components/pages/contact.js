import React from "react";

const Contact = () => {
  return (
    <div>
      <h1>email us at bakingblog@baking.com</h1>
    </div>
  );
};

export default Contact;
