import React from "react";

const SignUp = () => {
  return (
    <div>
      <h1>Sign Up For More!</h1>
      <signupForm />
    </div>
  );
};

export default SignUp;
